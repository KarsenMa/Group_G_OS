//Author: Damian Silvar
//Email: damian.silvar@okstate.edu
//Date: 4-2-25

#include "MutexThread.h"
#include "IPCSemaphore.h"

int main() {
    startThreads();   // mutex example
    startProcesses(); // semaphore example
    return 0;
}
