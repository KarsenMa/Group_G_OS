#ifndef IPCSEMAPHORE_H
#define IPCSEMAPHORE_H

void startProcesses();

#endif
