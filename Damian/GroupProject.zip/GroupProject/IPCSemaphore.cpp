//Author: Damian Silvar
//Email: damian.silvar
//Date: 4-2-25

#include "IPCSemaphore.h"
#include <iostream>
#include <semaphore.h>
#include <pthread.h>
#include <unistd.h>

sem_t sem; // Semaphore object

void* worker(void* arg) { // function for each proccess and thread
    int id = *((int*) arg);
    sem_wait(&sem);
    std::cout << "Process " << id << " accessing shared resource\n";
    sleep(1);
    sem_post(&sem);
    return nullptr;
}

void startProcesses() {  // create processes threads
    sem_init(&sem, 0, 1);

    pthread_t t1, t2;    // Two thread variables
    int id1 = 1, id2 = 2;   // Thread IDs

    if (pthread_create(&t1, nullptr, worker, &id1) != 0) { // first thread created
        std::cerr << "Failed to create thread 1\n";
    }

    if (pthread_create(&t2, nullptr, worker, &id2) != 0) { // second thread created
        std::cerr << "Failed to create thread 2\n";
    }

    // waits for both threads
    pthread_join(t1, nullptr);
    pthread_join(t2, nullptr);

    sem_destroy(&sem);  // semaphore destroy once threads executed
}