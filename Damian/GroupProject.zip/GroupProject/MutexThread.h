#ifndef MUTEXTHREAD_H
#define MUTEXTHREAD_H

void startThreads();

#endif
