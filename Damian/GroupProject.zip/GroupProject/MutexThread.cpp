//Author: Damian Silvar
//Email: damian.silvar@okstate.edu
//Date: 4-2-25

#include "MutexThread.h"
#include <iostream>
#include <thread>
#include <mutex>

std::mutex mtx;

void criticalSection(int id) {  // replicates critical section
    std::lock_guard<std::mutex> lock(mtx);
    std::cout << "Thread " << id << " is in the critical section\n";
    std::this_thread::sleep_for(std::chrono::seconds(1));
    std::cout << "Thread " << id << " is leaving the critical section\n";
}

void startThreads() {  // creates and executes two threads
    std::thread t1(criticalSection, 1);
    std::thread t2(criticalSection, 2);
    
    t1.join();  // waits for first thread
    t2.join();  // waits for second thread
}
